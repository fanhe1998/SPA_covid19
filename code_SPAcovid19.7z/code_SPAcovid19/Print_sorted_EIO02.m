function Print_sorted_EIO02(sorted, T_max, percent, Total_Emissions, filename, sectornames, thresh_banner)
%%%%%%%%%%%%%%%%%%%%%%%%
%
% Print the sorted paths to file
% Originally made by Glen Peters
% slight usability updates by Scott Matthews
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

paths = length(sorted);

fid = fopen(filename, 'w');

% the next line prints a summary of the threshold parameters in output
% file - can comment it out if you need to
if thresh_banner == 1
    fprintf(fid, 'Paths = %d, T_max = %d, percent = %2.5f, Total Effects = %d\n', paths, T_max, percent, Total_Emissions);
else
end

save sorted.mat sorted
for i=1:paths
    
    fprintf(fid, '%5d:%5d:%2.4f:%2.4f ', i, length(sorted(i).sequence)-1, sorted(i).value(1), sorted(i).value(2));
    for j=1:length(sorted(i).sequence)
        
        fprintf(fid,' %c %d %c %s', ':', sorted(i).sequence(j), ';',char(sectornames(sorted(i).sequence(j),1)));
    end
    fprintf(fid, '\n');
end    
    
fclose(fid);

end
