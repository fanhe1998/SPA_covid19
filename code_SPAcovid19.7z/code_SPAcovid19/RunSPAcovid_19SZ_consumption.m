clear all
load('IOanalysisSZ.mat')  % relative path to 2002 EIOLCA .mat file 

F = R;      % matrix of energy & GHG results, 1 is CO2 fossil

A = A;            % from the industry by commodity matrix
filename = 'SPA_covid_19';

% sector names in the external .mat file 

[rows, cols] = size(A);
sectornames=cell(rows,1);
for i=1:rows
    sectornames{i}=['Sector' num2str(i)];
end    

L = inv(eye(42)-A);            % industry by commodity total reqs (already made)

F_total = F*L;
y = InvC;

percent = 0.01;         % The "cut-off" of small sub-trees (percent of total effects)
T_max = 4;              % Max tiers to search

% this prints the T_max, percent, etc params in the file
% change to 0 or comment it out if not needed

thresh_banner=1;  

% this last command runs two other .m files in the zip file
% the parameters on the right hand side are the threshold parameters

SPAEIO02(F, A, y, F_total, T_max, percent, filename, sectornames, thresh_banner);
