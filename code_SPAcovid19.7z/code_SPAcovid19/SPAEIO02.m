function SPAEIO02(F, A, y, F_total, T_max, percent, filename, sectornames, thresh_banner)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Do a SPA
%
% Glen Peters
% Feb 2005
%
% tol is the percentage to cut of paths
%    Note that tol is not accurate as it uses the next paths
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Calculate the total emissions and tolerance
Total_Emissions = F_total*y;
tol = percent/100 * Total_Emissions;

disp('tolerance..')
disp(tol)

disp('Construct the tree...')
tic
%tree = Build_tree_func(F, A, y, F_total, 0, T_max, tol);
tree = Build_tree(F, A, y, F_total, T_max, tol);
toc

% Save the tree
file_tree = strcat(filename, '_tree_', num2str(T_max));
%save(file_tree, 'tree')

disp('Read tree...')
tic
paths = Read_tree(tree, size(A,1));
toc
%clear tree;

disp('Sort tree')
tic
sorted_paths = Sort_paths(paths);
toc

% Save the sorted paths
file_paths = strcat(filename, '_paths_', num2str(T_max));
save(file_paths, 'paths', 'sorted_paths','Total_Emissions')

file_print = strcat(filename,'.txt');
disp(strcat('Print sorted tree to file... ',file_print))
tic
Print_sorted_EIO02(sorted_paths, T_max, percent, Total_Emissions, file_print, sectornames, thresh_banner);
toc

total=0;
for i=1:length(sorted_paths)
    total = total + sorted_paths(i).value;
end
percent_effects_captured = total(1)/Total_Emissions*100;

output_text = ['The total number of paths is ', int2str(length(paths)), ' the total effects covered are ', num2str(total(1)), ' and covers ', num2str(percent_effects_captured), ' percent of emissions'];

disp(output_text)

end