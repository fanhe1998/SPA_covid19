function Read_tree_func(tree, N)
%%%%%%%%%%%%%%%%%%%
% Read_tree_func
% This function is called by Read_tree
%
% Read all the paths and values constructed in the tree
%
% The important thing to make this routine fast is not to read the subtrees
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%

global previous_path

if tree.value ~= -pi % null_tree, skip all the nodes in this sub-tree
    for i=1:N
        % There is a subtree
        if tree.next(i).value ~= -pi
            next_path.value = full(tree.next(i).value);
            next_path.sequence = tree.next(i).sequence;
            previous_path = [previous_path next_path];
            Read_tree_func(tree.next(i), N);
        end
    end
end
end
