function this_tree = Build_tree_func(F, A, y, F_total, T, T_max, tol, sequence)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Build_tree_func
%
% Construct the tree
%     - T is the current tier being worked on
%     - T_max is the maximum tier to be calculated
%     - tol is the minimum size to lop the tree
%     - sequence is the current sequence being worked on
% 
% NOTE: Zeroth tier, T=1, B*y
%       First tier, T=2, B*A*y
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N =length(y);

% null_tree is the empty tree, equivalent to a null pointer to a tree
% This is required since the array of structures must point to structures
% and is not a pointer. In C this would not be a problem in a dynamic tree
% structure
null_tree.sequence = uint16([]);
null_tree.value = -pi;
null_tree.next = 0;

if T == T_max
    % Build the final node
    this_tree.sequence = sequence;
    this_tree.value(1) = Build_tree_value(F, A, y, sequence, T);
    this_tree.value(2) = Calculate_tree_vector(F, A, y, F_total,sequence, T);
    
    for i=1:N
        this_tree.next(i) = null_tree;  % No more sub-trees to be constructed
    end    
else
    % Add a subtree (a new node)
    this_tree.sequence = sequence;
    this_tree.value = Build_tree_value(F, A, y, sequence, T);
    
    for i=1:N
       
        sequence_next = [sequence uint16(i)];
        if abs(Calculate_tree_vector(F, A, y, F_total, sequence_next,T+1)) < tol   %%%%% This is a slow line
            this_tree.next(i) = null_tree;
        else 
            this_tree.next(i) = Build_tree_func(F, A, y, F_total, T+1, T_max, tol, sequence_next);
        end    
    end
    if numel(sequence)>0
        this_tree.value(2) = Calculate_tree_vector(F, A, y, F_total,sequence, T);
    else
    end
end

end