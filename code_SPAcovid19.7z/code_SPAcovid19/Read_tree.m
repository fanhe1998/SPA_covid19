function read_paths = Read_tree(tree, N)
%%%%%%%%%%%%%%%%%%%
% Read_tree
%
% This function is the driver for Read_tree_func
%
% To get this to work required the creation of the global variable
% previous_path. This is because Matlab does not allow dynamic use of
% pointers as in C and it does not allow variables to be returned in
% functions
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%


global previous_path

previous_path = [];
Read_tree_func(tree, N);
read_paths = previous_path;
end