function Value = Calculate_tree_vector(F, A, y, F_total, sequence, T)
%%%%%%%%%%%%%%%%%
% Calculate_tree_vector(F, A, y, F_total, sequence, T)
%
% This function calculates the total value of the tree below a given node.
% It includes the direct value from the node itself
%
% F_total is included in this function directly as it speeds up the
% process. For big matrices it takes a long time to invert
%
% sequence is the path to the node, eg [32 56 29] will calculate the value
% of the tree after following the path 32 to 56 to 29
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%component = Build_vector_component(A, sequence) * y(sequence(1),1);

component = y(sequence(1),1);
for t=2:T
    component = component * A(sequence(t), sequence(t-1));
end

vector = sparse(double(sequence(T)), 1, component, size(y,1), 1);

Value = F_total*vector;
end

