function tree_to_build = Build_tree(F, A, y, F_total, T_max, tol)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Build_tree
%
% Driver for Build_tree_func
%
% Construct the tree
%     - T_max is the maximum tier to be calculated
%     - tol is the minimum size to lop the tree
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('tolerance..')
disp(tol)

tree_to_build = Build_tree_func(F, A, y, F_total, 0, T_max, tol, uint16([]));
end