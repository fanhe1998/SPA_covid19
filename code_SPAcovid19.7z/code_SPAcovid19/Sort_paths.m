function sorted = Sort_paths(paths)
% Sort the paths in terms of value
save paths.mat paths

N = length(paths);

i=1;
while i <= N
    % Find the biggest number
    largest = -1e10;
    largest_index = 0;
    for j=i:N  
        if abs(paths(j).value(1)) > largest
            largest = paths(j).value(1);
            largest_index = j;
        end
    end
    
    % Swap the largest with the beginning of the sub-array
    if largest_index > 0
        temp = paths(i);
        paths(i) = paths(largest_index);
        paths(largest_index) = temp;
    end    
    
    i=i+1;
end
sorted = paths;
end